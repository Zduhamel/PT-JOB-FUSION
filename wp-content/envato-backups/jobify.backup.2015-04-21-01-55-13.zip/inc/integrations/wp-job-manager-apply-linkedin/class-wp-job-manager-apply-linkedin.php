<?php

class Jobify_WP_Job_Manager_Apply_LinkedIn {

	public function __construct() {

	}

}

$GLOBALS[ 'jobify_job_manager_apply_linked_in' ] = new Jobify_WP_Job_Manager_Apply_LinkedIn();